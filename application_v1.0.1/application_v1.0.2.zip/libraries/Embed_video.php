<?php 

/**
* 
*/
class Embed_video
{
	
	function __construct()
	{
		# code...
	}
	public function get($url='')
	{
		# code...

	}
}