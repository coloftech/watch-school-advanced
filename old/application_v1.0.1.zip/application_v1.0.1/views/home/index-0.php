<div class="post-index">
	

  
<div class="col-md-9 panel panel-content left">
	LATEST VIDEO
	<div class="video-anime">
		<?php foreach ($list_mostviews as $key): ?>
			
		<div class="col-md-3 col-sm-6 col-xs-12 cover-contents" data-slug="<?=$key->slug?>">
			<div class="cover-countdown"></div>
			<a class="cover-photo" data-cover="<?=$key->thumbnail?>"><img src="<?=$key->thumbnail?>"></a>
			<div class="cover-title"><?=$key->title?></div>

		</div>
		<?php endforeach ?>

	</div>
	<div class="video-drama">
		
	</div>
	<div class="video-movie">
		
	</div>


</div>
  




	<!-- end of anime latest -->



	<div class="col-md-3 panel panel-content right">
		

    Livechart on maintenance
</div>





</div>


<script type="text/javascript">
/* $(function(){
 
  $('.cover-photo').each(function(){
    $(this).attr('data-cover',function(e){

          var url = $(this).data('cover');

          if(url.length <= 0){
          	url = '<?=base_url("assets/images/default.jpg")?>';
          }
          
      $(this).css('background','url('+url+')');
      		.css('background-size','100% 100%')
      		.css('background-repeat','no-repeat');
    }); 

  });
});
*/

$('.cover-contents').on('click',function(){
	var slug = $(this).data('slug');
	window.location = '<?php echo site_url("watch/v/'+slug+'")?>';
})
</script>