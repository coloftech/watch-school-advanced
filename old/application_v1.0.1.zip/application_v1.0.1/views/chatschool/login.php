<div class="chatschool">
  <div class="panel panel-primary">
    <div class="panel-heading">
       <label class="chat-icon"><i class="fa fa-comment"></i></label> <label class="heading-status">
                Watchschool Live chat
            </label>
     
     <label class="heading-close"> 
     <a href="javascript:void(0)"  class="btn btn-primary btn-sm chat-form-close"><i class=" fa fa-remove"></i></a>
     </label>
    </div>
      <div class="panel-body " id="chat-container">
        
        <div class="colored" >
 <div class="col-md-12"></div>
    <div class="col-md-12">
        <div class="" style="margin-top: 30px">
            <div class="col-md-12  contcustom" id="contentdiv" >
                <form method="POST" id="login-frm">
                    <br>
                    <h2>Login</h2>
                    <div class="message"></div>
                    <div class="form-group">
                        <input type="text" name="username" id="Username" class="form-control" placeholder="Username" required="required" autofocus="autofocus"/>
                    </div>
                    <div class="form-group">
                         <input type="password" name="password" class="form-control" placeholder="Password" required="required" />
                    </div>
                    <button class="btn btn-block btn-default btn-success" id="login" type="submit"><i class="fa fa-lock"></i> Login</button>
                </form> <br>
                <button class="btn btn-block btn-default btn-primary" id="create-account" type="submit"><i class="fa fa-plus-circle"></i> Register</button>
            </div>
        </div>
    </div>
</div> 



      </div>
  </div>
</div>
