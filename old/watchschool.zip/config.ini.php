; <?php exit(); // DO NOT DELETE ?>
; DO NOT DELETE THE ABOVE LINE!!!
; Doing so will expose this configuration file through your web site!


;;;;;;;;;;;;;;;;;;;;
; General Settings ;
;;;;;;;;;;;;;;;;;;;;

[database]
hostname = 'localhost'
username = 'root'
password = 
dbname = 'test'
dbprefix = 'q_'
db_debug = 'FALSE'


[dir]
upload = 'public'
system = 'system'
application = 'application'

[urls]
base_url = 'http://anime-vid.eo'
site_url = 

[installation]
installed = 'on'
maintenance = 'off'