<!DOCTYPE html>
<html>
<head>
	<title><?=isset($site_title) ? $site_title : 'Watch School'?></title>

        <link rel="icon" href="<?=base_url();?>assets/images/icon-35.png"  sizes="35x35"/>
        <link rel="icon" href="<?=base_url();?>assets/images/icon-16.png"  sizes="16x16"/>
	<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/chat.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css">

<!-- Custom CSS -->
<?php $this->minify->css(array('chat.css','default.css'));
echo $this->minify->deploy_css(); ?>

</head>
<body class="watchschool">


<!-- Header -->
<header id="top" class="header">
    <div class="text-vertical-center">
      


<div class="container">
<nav class="navbar navbar-default watchschool-navbar">
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                      <button type="button" data-target="#nav-portal" data-toggle="collapse" class="navbar-toggle">
                          <span class="sr-only">Toggle navigation</span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                      </button>

                      <a class="navbar-brand" href="<?=site_url();?>"><div class="logo"><i class="fa fa-institution"></i> WATCHSCHOOL</div></a>
                
                  </div>
                  <!-- Collection of nav links, forms, and other content for toggling -->
                  <div id="nav-portal" class="collapse navbar-collapse">
                  <form class="form" action="../home/search" method="get">
                     <div class="col-md-4 form-search "><input type="text" class="form-control" name="q"><button class="btn btn-info pull-right" type="submit"><i class="fa fa-search"></i></button></div>
                     

                  </form>
                      
                        <ul class="nav navbar-nav navbar-right" style="margin-right:10px;">

                          <li class="home"> <a href="<?php echo site_url(); ?>">Home</a></li>
                          <li class="home hidden"> <a href="<?php echo site_url('livechart'); ?>">Live Chart</a></li>
                          <li class="newvideos"> <a href="<?php echo site_url('watch/new_upload'); ?>">Latest</a></li>
                          <li class="anime"> <a href="<?php echo site_url('watch/anime'); ?>">Anime</a></li>
                          <li class="movies"> <a href="<?php echo site_url('watch/movies'); ?>">Movies</a></li>
              <?php 

                    if($this->authentication->is_loggedin()){
                      

                    $id = $this->authentication->read('identifier');
                    //echo "$id";
                    if($id == 1){
                      echo "<li class=\"home\"> <a href=\"".site_url('watchschool_anime_admin_home')."\">Administrator</a></li>";
                    }
                    }

                 ?>
                                          
                          
                      </ul>

                  </div>
              </nav>
  
<?php echo $body; ?>
<!-- Code to Display the chat button -->
<a href="javascript:void(0)" id="chattoggle" class="btn-chat btn  fixed-bottom pull-right">
   <i class="fa fa-comments-o fa-3x"></i> Live chart
    <span class="badge progress-bar-danger"></span>
</a>

<!--CHAT CONTAINER STARTS HERE-->
<div id="chat-container" class="fixed"></div>



    </div>

</header>
</div>
<script type="text/javascript">
  
var base_url = '<?php echo base_url(); ?>';

</script>
<script type="text/javascript">var base = "<?php echo base_url().'index.php/';?>";</script>
<script src="<?=base_url('assets/js/jquery-1.11.0.min.js')?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugin/jquery.countdown-2.2.0/jquery.countdown.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/main.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/video/video.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/chat.js"></script>
<script type="text/javascript">
  $(document).ready(function(){



  if(sessionStorage){
    // Store data
    var is_chat = sessionStorage.getItem("livechat");
    if(is_chat === undefined){

    sessionStorage.setItem("livechat", "hidechat");
    }else{
      if(is_chat == 'hidechat'){

          $('#chat-container').toggle('slide', {
              direction: 'right'
          }, 500);
          $('#chat-box').hide();
        }
        }
    }
 
    // Retrieve data
   
  });
  $('#chattoggle').on('click',function(e){
    if(sessionStorage){
    // Store data
          sessionStorage.setItem("livechat", "show");
    }
       
  });

$(document).on('click', '.chat-form-close', function(){
   if(sessionStorage){
    // Store data
          sessionStorage.setItem("livechat", "hidechat");
    }
});

  
</script>
</body>
</html>