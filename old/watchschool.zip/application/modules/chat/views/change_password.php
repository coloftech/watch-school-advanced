<div class="colored" >
 <div class="col-md-12"></div>
    <div class="col-md-12">
            <div class="col-md-12  contcustom" id="contentdiv" >
                <form method="POST" id="changepassword-frm">
                    <h4>Change Password</h4>
                    <div class="message"></div>
                    <div class="form-group">
                        <input type="password" name="current_password" class="form-control" placeholder="Current Password" required="required" />
                    </div>
                    <div class="form-group">
                        <input type="password" name="new_password" class="form-control" placeholder="New Password" required="required" />
                    </div>
                    <div class="form-group">
                        <input type="password" name="confirm_newpassword" class="form-control" placeholder="Confirm Password" required="required" />
                    </div>
              
                    <button class="btn btn-block btn-default btn-success" id="update-password" type="submit"><i class="fa fa-save"></i> Change Password</button>
                    <br>
                </form>
                <button class="btn btn-block btn-default btn-primary goback"> <i class="fa fa-arrow-circle-left"></i> Back to Chat</button>
            </div>
    </div>
</div>